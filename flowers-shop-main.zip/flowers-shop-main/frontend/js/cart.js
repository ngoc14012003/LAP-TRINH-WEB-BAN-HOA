// Toast notification
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${
      type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'
    }</span>
    <span class="toast-message">${message}</span>
  `;
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add('show'), 10);
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// Format price to VND
function formatVND(price) {
  return price.toLocaleString('vi-VN') + '₫';
}

// Load cart items
function loadCart() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const container = document.getElementById('cart-items');

  if (cart.length === 0) {
    container.innerHTML =
      '<p style="text-align: center; padding: 2rem;">Giỏ hàng trống</p>';
    updateTotals();
    return;
  }

  container.innerHTML = cart
    .map(
      (item, index) => `
        <div class="cart-item">
            <div class="cart-item-info">
                <h3>${item.name}</h3>
                <p>${formatVND(item.price)} /sản phẩm</p>
            </div>
            <div class="cart-item-actions">
                <div class="quantity-controls">
                    <button class="quantity-btn" onclick="window.updateQuantity(${index}, -1)">-</button>
                    <span>${item.quantity}</span>
                    <button class="quantity-btn" onclick="window.updateQuantity(${index}, 1)">+</button>
                </div>
                <div style="min-width: 80px; text-align: right;">
                    <strong>${formatVND(item.price * item.quantity)}</strong>
                </div>
                <button class="btn btn-delete btn-small" onclick="window.removeItem(${index})">Xóa</button>
            </div>
        </div>
    `,
    )
    .join('');

  updateTotals();
}

// Update quantity - global function
window.updateQuantity = function (index, change) {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  cart[index].quantity += change;

  if (cart[index].quantity <= 0) {
    cart.splice(index, 1);
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  loadCart();
  updateCartCount();
};

// Remove item - global function
window.removeItem = function (index) {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  cart.splice(index, 1);
  localStorage.setItem('cart', JSON.stringify(cart));
  loadCart();
  updateCartCount();
};

// Update totals
function updateTotals() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const subtotal = cart.reduce(
    (total, item) => total + item.price * item.quantity,
    0,
  );
  const shipping = cart.length > 0 ? 50000 : 0; // 50,000 VND
  const total = subtotal + shipping;

  document.getElementById('subtotal').textContent = formatVND(subtotal);
  document.getElementById('shipping').textContent = formatVND(shipping);
  document.getElementById('total').textContent = formatVND(total);
}

// Update cart count
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const count = cart.reduce((total, item) => total + item.quantity, 0);
  document.getElementById('cart-count').textContent = count;
}

// Update user menu
function updateUserMenu() {
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const userMenu = document.getElementById('user-menu');
  const loginLink = document.getElementById('login-link');
  const userName = document.getElementById('user-name');

  if (user && user.name) {
    if (userMenu) userMenu.style.display = 'block';
    if (loginLink) loginLink.style.display = 'none';
    if (userName) userName.textContent = user.name;
  } else {
    if (userMenu) userMenu.style.display = 'none';
    if (loginLink) loginLink.style.display = 'block';
  }
}

// Logout function
function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  localStorage.removeItem('adminUser');
  window.location.href = '/';
}

// Checkout
document.getElementById('checkout-btn').addEventListener('click', () => {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  if (cart.length === 0) {
    showToast('Giỏ hàng trống!', 'warning');
    return;
  }
  window.location.href = '/checkout.html';
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadCart();
  updateCartCount();
  updateUserMenu();

  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      logout();
    });
  }
});
