# Flowers Shop Backend

## Setup Instructions

### Prerequisites

- Java 17 or higher
- Maven 3.6+
- MySQL 8.0+

### Database Setup

1. Install MySQL
2. Create a database named `flowers_shop` or let the application create it automatically
3. Update database credentials in `src/main/resources/application.properties` if needed

### Running the Application

```bash
cd backend
mvnw spring-boot:run
```

The API will be available at `http://localhost:8080`

### API Endpoints

#### Users

- GET /api/users - Get all users
- GET /api/users/{id} - Get user by ID
- POST /api/users - Create user
- PUT /api/users/{id} - Update user
- DELETE /api/users/{id} - Delete user

#### Products

- GET /api/products - Get all products
- GET /api/products/{id} - Get product by ID
- GET /api/products/category/{category} - Get products by category
- POST /api/products - Create product
- PUT /api/products/{id} - Update product
- DELETE /api/products/{id} - Delete product

#### Orders

- GET /api/orders - Get all orders
- GET /api/orders/{id} - Get order by ID
- GET /api/orders/user/{userId} - Get orders by user
- GET /api/orders/status/{status} - Get orders by status
- POST /api/orders - Create order
- PATCH /api/orders/{id}/status - Update order status
- DELETE /api/orders/{id} - Delete order
