const API_URL = '/api';

// Check if already logged in
if (localStorage.getItem('token')) {
  window.location.href = '/';
}

// Handle signup form submission
document.getElementById('signup-form').addEventListener('submit', async (e) => {
  e.preventDefault();

  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const phone = document.getElementById('phone').value;
  const address = document.getElementById('address').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirm-password').value;
  const errorMsg = document.getElementById('error-message');
  const successMsg = document.getElementById('success-message');

  errorMsg.style.display = 'none';
  successMsg.style.display = 'none';

  // Validate passwords match
  if (password !== confirmPassword) {
    errorMsg.textContent = 'Mật khẩu không khớp!';
    errorMsg.style.display = 'block';
    return;
  }

  // Validate password length
  if (password.length < 6) {
    errorMsg.textContent = 'Mật khẩu phải có ít nhất 6 ký tự!';
    errorMsg.style.display = 'block';
    return;
  }

  try {
    const response = await fetch(`${API_URL}/auth/signup`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: name,
        email: email,
        phone: phone,
        address: address,
        password: password,
      }),
    });

    if (response.ok) {
      const data = await response.json();

      // Store JWT token and user info
      localStorage.setItem('token', data.token);
      localStorage.setItem(
        'user',
        JSON.stringify({
          id: data.id,
          name: data.name,
          email: data.email,
          role: data.role,
        }),
      );

      successMsg.textContent = 'Tạo tài khoản thành công! Đang chuyển hướng...';
      successMsg.style.display = 'block';

      setTimeout(() => {
        window.location.href = '/';
      }, 1500);
    } else {
      const error = await response.text();
      errorMsg.textContent = error || 'Đăng ký thất bại. Vui lòng thử lại.';
      errorMsg.style.display = 'block';
    }
  } catch (error) {
    console.error('Signup error:', error);
    errorMsg.textContent = 'Lỗi mạng. Vui lòng kiểm tra kết nối của bạn.';
    errorMsg.style.display = 'block';
  }
});
