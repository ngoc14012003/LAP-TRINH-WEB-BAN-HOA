const API_URL = '/api';

// Show toast notification
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type} show`;

  const icons = {
    success: '✓',
    error: '✕',
    warning: '⚠',
    info: 'ℹ',
  };

  toast.innerHTML = `
    <span class="toast-icon">${icons[type] || icons.success}</span>
    <span class="toast-message">${message}</span>
  `;

  document.body.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 5000);
}

// Update user menu
function updateUserMenu() {
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const userMenu = document.getElementById('user-menu');
  const loginLink = document.getElementById('login-link');
  const userName = document.getElementById('user-name');

  if (user && user.name) {
    if (userMenu) userMenu.style.display = 'block';
    if (loginLink) loginLink.style.display = 'none';
    if (userName) userName.textContent = user.name;
  } else {
    if (userMenu) userMenu.style.display = 'none';
    if (loginLink) loginLink.style.display = 'block';
  }
}

// Logout function
function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  localStorage.removeItem('adminUser');
  window.location.href = '/';
}

// Load order summary
function loadOrderSummary() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const container = document.getElementById('order-items');

  if (cart.length === 0) {
    window.location.href = '/cart.html';
    return;
  }

  container.innerHTML = cart
    .map(
      (item) => `
        <div class="summary-row">
            <span>${item.name} x ${item.quantity}</span>
            <span>${(item.price * item.quantity).toLocaleString(
              'vi-VN',
            )}₫</span>
        </div>
    `,
    )
    .join('');

  const subtotal = cart.reduce(
    (total, item) => total + item.price * item.quantity,
    0,
  );
  const shipping = 50000; // 50,000 VND
  const total = subtotal + shipping;

  document.getElementById('order-total').textContent = `${total.toLocaleString(
    'vi-VN',
  )}₫`;
}

// Pre-fill user info if logged in
function prefillUserInfo() {
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  if (user && user.name) {
    document.getElementById('name').value = user.name || '';
    document.getElementById('email').value = user.email || '';
    document.getElementById('phone').value = user.phone || '';
    document.getElementById('address').value = user.address || '';
  }
}

// Handle checkout form submission
document
  .getElementById('checkout-form')
  .addEventListener('submit', async (e) => {
    e.preventDefault();

    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    const token = localStorage.getItem('token');

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const address = document.getElementById('address').value;

    // Calculate total
    const subtotal = cart.reduce(
      (total, item) => total + item.price * item.quantity,
      0,
    );
    const shipping = 50000; // 50,000 VND
    const totalAmount = subtotal + shipping;

    try {
      let userId = user.id;

      // If not logged in, create guest user
      if (!token || !userId) {
        try {
          const signupResponse = await fetch(`${API_URL}/auth/signup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              name: name,
              email: email,
              phone: phone,
              address: address,
              password: 'guest' + Date.now(), // Random password for guest
            }),
          });

          if (signupResponse.ok) {
            const guestUser = await signupResponse.json();
            userId = guestUser.id;
          } else {
            // User might already exist, try to get by email
            const usersResponse = await fetch(`${API_URL}/users`);
            if (usersResponse.ok) {
              const users = await usersResponse.json();
              const existingUser = users.find((u) => u.email === email);
              if (existingUser) {
                userId = existingUser.id;
              }
            }
          }
        } catch (error) {
          console.error('Guest user creation error:', error);
        }
      }

      if (!userId) {
        showToast('Không thể tạo tài khoản. Vui lòng thử lại!', 'error');
        return;
      }

      // Create order
      const order = {
        user: { id: userId },
        totalAmount: totalAmount,
        status: 'PENDING',
        shippingAddress: address,
        phone: phone,
        items: cart.map((item) => ({
          product: { id: item.id },
          quantity: item.quantity,
          price: item.price,
        })),
      };

      const headers = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const orderResponse = await fetch(`${API_URL}/orders`, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(order),
      });

      if (orderResponse.ok) {
        const createdOrder = await orderResponse.json();
        localStorage.removeItem('cart');
        showToast(
          `Đặt hàng thành công! Mã đơn hàng: ${createdOrder.id}`,
          'success',
        );
        setTimeout(() => {
          window.location.href = '/';
        }, 5000);
      } else {
        const error = await orderResponse.text();
        throw new Error(error || 'Tạo đơn hàng thất bại');
      }
    } catch (error) {
      console.error('Checkout error:', error);
      showToast('Lỗi khi đặt hàng. Vui lòng thử lại!', 'error');
    }
  });

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadOrderSummary();
  prefillUserInfo();
  updateUserMenu();

  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      logout();
    });
  }
});
