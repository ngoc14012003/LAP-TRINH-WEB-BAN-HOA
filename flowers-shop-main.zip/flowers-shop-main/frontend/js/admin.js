const API_URL = '/api';

// Show toast notification
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type} show`;

  const icons = {
    success: '✓',
    error: '✕',
    warning: '⚠',
    info: 'ℹ',
  };

  toast.innerHTML = `
    <span class="toast-icon">${icons[type] || icons.success}</span>
    <span class="toast-message">${message}</span>
  `;

  document.body.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3000);
}

// Format currency to VND
function formatVND(price) {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
  }).format(price);
}

// Check authentication
const adminUser = JSON.parse(localStorage.getItem('adminUser'));
const token = localStorage.getItem('token');

if (!adminUser || adminUser.role !== 'ADMIN' || !token) {
  window.location.href = '/login.html';
}

// Verify token with backend
async function verifyToken() {
  try {
    const response = await fetch(`${API_URL}/auth/verify`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      localStorage.removeItem('adminUser');
      localStorage.removeItem('token');
      window.location.href = '/login.html';
    }
  } catch (error) {
    console.error('Token verification failed:', error);
  }
}

verifyToken();

// Load categories for dropdown
async function loadCategoriesDropdown() {
  try {
    const response = await fetch(`${API_URL}/categories`);
    const categories = await response.json();

    const select = document.getElementById('product-category');
    select.innerHTML = '<option value="">Chọn Danh Mục</option>';

    categories.forEach((category) => {
      const option = document.createElement('option');
      option.value = category.id;
      option.textContent = category.name;
      select.appendChild(option);
    });
  } catch (error) {
    console.error('Error loading categories:', error);
  }
}

// Display admin username
document.getElementById(
  'admin-username',
).textContent = `Xin chào, ${adminUser.name}`;

// Logout functionality
document.getElementById('logout-btn').addEventListener('click', (e) => {
  e.preventDefault();
  localStorage.removeItem('user');
  localStorage.removeItem('token');
  window.location.href = '/login.html';
});

// Navigation between sections
document.querySelectorAll('.admin-menu a').forEach((link) => {
  link.addEventListener('click', (e) => {
    e.preventDefault();

    // Update active link
    document
      .querySelectorAll('.admin-menu a')
      .forEach((l) => l.classList.remove('active'));
    link.classList.add('active');

    // Show corresponding section
    const section = link.dataset.section;
    document
      .querySelectorAll('.admin-section')
      .forEach((s) => s.classList.remove('active'));
    document.getElementById(section).classList.add('active');

    // Load data for section
    if (section === 'products') loadProducts();
    if (section === 'orders') loadOrders();
    if (section === 'users') loadUsers();
  });
});

// Load dashboard stats
async function loadDashboardStats() {
  try {
    const [products, orders, users] = await Promise.all([
      fetch(`${API_URL}/products`).then((r) => r.json()),
      fetch(`${API_URL}/orders`).then((r) => r.json()),
      fetch(`${API_URL}/users`).then((r) => r.json()),
    ]);

    document.getElementById('total-products').textContent = products.length;
    document.getElementById('total-orders').textContent = orders.length;
    document.getElementById('total-users').textContent = users.length;
    document.getElementById('pending-orders').textContent = orders.filter(
      (o) => o.status === 'PENDING',
    ).length;
  } catch (error) {
    console.error('Error loading stats:', error);
  }
}

// Products Management
async function loadProducts() {
  try {
    const response = await fetch(`${API_URL}/products`);
    const products = await response.json();

    const tbody = document.getElementById('products-table-body');
    tbody.innerHTML = products
      .map(
        (product) => `
            <tr>
                <td>${product.id}</td>
                <td>${product.name}</td>
                <td>${product.category?.name || 'N/A'}</td>
                <td>${formatVND(product.price)}</td>
                <td>${product.stock}</td>
                <td class="action-buttons">
                    <button class="btn btn-edit btn-small" onclick="editProduct(${
                      product.id
                    })">Sửa</button>
                    <button class="btn btn-delete btn-small" onclick="deleteProduct(${
                      product.id
                    })">Xóa</button>
                </td>
            </tr>
        `,
      )
      .join('');
  } catch (error) {
    console.error('Error loading products:', error);
  }
}

// Open product modal
function openProductModal(productId = null) {
  const modal = document.getElementById('product-modal');
  modal.classList.add('active');

  // Load categories first
  loadCategoriesDropdown();

  if (productId) {
    document.getElementById('modal-title').textContent = 'Sửa Sản Phẩm';
    loadProductData(productId);
  } else {
    document.getElementById('modal-title').textContent = 'Thêm Sản Phẩm';
    document.getElementById('product-form').reset();
    document.getElementById('product-id').value = '';
  }
}

// Close product modal
function closeProductModal() {
  document.getElementById('product-modal').classList.remove('active');
}

// Load product data for editing
async function loadProductData(productId) {
  try {
    const response = await fetch(`${API_URL}/products/${productId}`);
    const product = await response.json();

    document.getElementById('product-id').value = product.id;
    document.getElementById('product-name').value = product.name;
    document.getElementById('product-description').value =
      product.description || '';
    document.getElementById('product-category').value =
      product.category?.id || '';
    document.getElementById('product-price').value = product.price;
    document.getElementById('product-stock').value = product.stock;
    document.getElementById('product-image').value = product.imageUrl || '';
  } catch (error) {
    console.error('Error loading product:', error);
  }
}

// Edit product
function editProduct(productId) {
  openProductModal(productId);
}

// Delete product
async function deleteProduct(productId) {
  if (!confirm('Bạn có chắc muốn xóa sản phẩm này?')) return;

  try {
    await fetch(`${API_URL}/products/${productId}`, { method: 'DELETE' });
    loadProducts();
    loadDashboardStats();
  } catch (error) {
    console.error('Error deleting product:', error);
    showToast('Lỗi khi xóa sản phẩm', 'error');
  }
}

// Handle product form submission
document
  .getElementById('product-form')
  .addEventListener('submit', async (e) => {
    e.preventDefault();

    const productId = document.getElementById('product-id').value;
    const categoryId = document.getElementById('product-category').value;

    const product = {
      name: document.getElementById('product-name').value,
      description: document.getElementById('product-description').value,
      category: categoryId ? { id: parseInt(categoryId) } : null,
      price: parseFloat(document.getElementById('product-price').value),
      stock: parseInt(document.getElementById('product-stock').value),
      imageUrl: document.getElementById('product-image').value,
    };

    try {
      const url = productId
        ? `${API_URL}/products/${productId}`
        : `${API_URL}/products`;
      const method = productId ? 'PUT' : 'POST';

      await fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product),
      });

      closeProductModal();
      loadProducts();
      loadDashboardStats();
    } catch (error) {
      console.error('Error saving product:', error);
      showToast('Lỗi khi lưu sản phẩm', 'error');
    }
  });

// Orders Management
async function loadOrders() {
  try {
    const response = await fetch(`${API_URL}/orders`);
    const orders = await response.json();

    const tbody = document.getElementById('orders-table-body');
    tbody.innerHTML = orders
      .map(
        (order) => `
            <tr>
                <td>${order.id}</td>
                <td>${order.user?.name || 'N/A'}</td>
                <td>${formatVND(order.totalAmount)}</td>
                <td>
                    <select onchange="updateOrderStatus(${
                      order.id
                    }, this.value)" class="status-badge status-${order.status.toLowerCase()}">
                        <option value="PENDING" ${
                          order.status === 'PENDING' ? 'selected' : ''
                        }>Chờ Xử Lý</option>
                        <option value="PROCESSING" ${
                          order.status === 'PROCESSING' ? 'selected' : ''
                        }>Đang Xử Lý</option>
                        <option value="SHIPPED" ${
                          order.status === 'SHIPPED' ? 'selected' : ''
                        }>Đang Giao</option>
                        <option value="DELIVERED" ${
                          order.status === 'DELIVERED' ? 'selected' : ''
                        }>Đã Giao</option>
                        <option value="CANCELLED" ${
                          order.status === 'CANCELLED' ? 'selected' : ''
                        }>Đã Hủy</option>
                    </select>
                </td>
                <td>${new Date(order.createdAt).toLocaleDateString()}</td>
                <td class="action-buttons">
                    <button class="btn btn-delete btn-small" onclick="deleteOrder(${
                      order.id
                    })">Xóa</button>
                </td>
            </tr>
        `,
      )
      .join('');
  } catch (error) {
    console.error('Error loading orders:', error);
  }
}

// Update order status
async function updateOrderStatus(orderId, status) {
  try {
    const response = await fetch(`${API_URL}/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ status: status }),
    });

    if (!response.ok) {
      throw new Error('Failed to update order status');
    }

    loadOrders();
    loadDashboardStats();
    showToast('Cập nhật trạng thái đơn hàng thành công!', 'success');
  } catch (error) {
    console.error('Error updating order status:', error);
    showToast('Lỗi khi cập nhật trạng thái đơn hàng', 'error');
  }
}

// Delete order
async function deleteOrder(orderId) {
  if (!confirm('Bạn có chắc muốn xóa đơn hàng này?')) return;

  try {
    await fetch(`${API_URL}/orders/${orderId}`, { method: 'DELETE' });
    loadOrders();
    loadDashboardStats();
  } catch (error) {
    console.error('Error deleting order:', error);
    showToast('Lỗi khi xóa đơn hàng', 'error');
  }
}

// Users Management
async function loadUsers() {
  try {
    const response = await fetch(`${API_URL}/users`);
    const users = await response.json();

    const tbody = document.getElementById('users-table-body');
    tbody.innerHTML = users
      .map(
        (user) => `
            <tr>
                <td>${user.id}</td>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>
                    <select onchange="updateUserRole(${
                      user.id
                    }, this.value)" class="status-badge status-${user.role.toLowerCase()}">
                        <option value="USER" ${
                          user.role === 'USER' ? 'selected' : ''
                        }>USER</option>
                        <option value="ADMIN" ${
                          user.role === 'ADMIN' ? 'selected' : ''
                        }>ADMIN</option>
                    </select>
                </td>
                <td class="action-buttons">
                    <button class="btn btn-delete btn-small" onclick="deleteUser(${
                      user.id
                    })">Xóa</button>
                </td>
            </tr>
        `,
      )
      .join('');
  } catch (error) {
    console.error('Error loading users:', error);
  }
}

// Update user role
async function updateUserRole(userId, role) {
  try {
    const response = await fetch(`${API_URL}/users/${userId}/role`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ role: role }),
    });

    if (!response.ok) {
      throw new Error('Failed to update user role');
    }

    loadUsers();
    loadDashboardStats();
    showToast('Cập nhật vai trò người dùng thành công!', 'success');
  } catch (error) {
    console.error('Error updating user role:', error);
    showToast('Lỗi khi cập nhật vai trò người dùng', 'error');
  }
}

// Delete user
async function deleteUser(userId) {
  if (!confirm('Bạn có chắc muốn xóa người dùng này?')) return;

  try {
    await fetch(`${API_URL}/users/${userId}`, { method: 'DELETE' });
    loadUsers();
    loadDashboardStats();
  } catch (error) {
    console.error('Error deleting user:', error);
    showToast('Lỗi khi xóa người dùng', 'error');
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadDashboardStats();
});

// Make functions globally accessible
window.openProductModal = openProductModal;
window.closeProductModal = closeProductModal;
window.editProduct = editProduct;
window.deleteProduct = deleteProduct;
window.updateOrderStatus = updateOrderStatus;
window.deleteOrder = deleteOrder;
window.updateUserRole = updateUserRole;
window.deleteUser = deleteUser;
