-- Thêm danh mục
INSERT INTO categories
  (name, description)
VALUES
  ('Hoa 20/11', 'Hoa đẹp với nhiều màu sắc tươi sáng - hoàn hảo để bày tỏ lòng biết ơn'),
  ('Hoa tốt nghiệp', 'Hoa thanh lịch hoàn hảo cho mọi dịp - có sẵn trong nhiều màu sắc rực rỡ'),
  ('Hoa 8/3', 'Hoa đẹp duyên dáng với hương thơm quyến rũ - lý tưởng cho các dịp lễ'),
  ('Hoa sinh nhật', 'Hoa mang đến vẻ thanh lịch cho mọi không gian'),
  ('Hoa khai trương', 'Các bó hoa hỗn hợp được tuyển chọn cẩn thận'),
  ('Hoa giáng sinh', 'Hoa đặc biệt cho ngày trọng đại của năm'),
  ('Hoa Valentine', 'Hoa biểu tượng kinh điển của tình yêu và lãng mạn');

-- Thêm người dùng Admin (username: admin, mật khẩu: 123456)
-- Lưu ý: Trong môi trường production, sử dụng mật khẩu được mã hóa đúng cách với BCrypt
INSERT INTO users
  (email, password, name, role, phone, address)
VALUES
  ('admin', '$2a$10$/KEoua/pvAbFgm.2Lwv8nuhXANmWd.D2kRbVOatWR7SWgK/do.7Ke', 'Quản Trị Viên', 'ADMIN','0123456789', 'Hanoi');

-- Thêm sản phẩm
-- Hoa Hồng
INSERT INTO products
  (name, description, price, stock, category_id, image_url)
VALUES
  ('Bó Hoa Hồng Đỏ', 'Bó hoa hồng đỏ kinh điển được cắm đẹp mắt', 1199000, 50, 1, 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=400'),
  ('Hoa Hồng Trắng Thanh Lịch', 'Hoa hồng trắng tinh khôi tượng trưng cho sự trong sáng và thuần khiết', 1099000, 40, 1, 'https://images.unsplash.com/photo-1582794543139-8ac9cb0f7b11?w=400'),
  ('Hoa Hồng Hồng Ngọt Ngào', 'Hoa hồng hồng nhẹ nhàng hoàn hảo để thể hiện sự ngưỡng mộ', 1029000, 35, 1, 'https://images.unsplash.com/photo-1455659817273-f96807779a8a?w=400'),
  ('Hoa Hồng Vàng Rực Rỡ', 'Hoa hồng vàng tươi vui mang lại sự ấm áp và niềm vui', 959000, 30, 1, 'https://images.unsplash.com/photo-1586024297259-c2f0b00768d9?w=400');

-- Hoa Tulip
INSERT INTO products
  (name, description, price, stock, category_id, image_url)
VALUES
  ('Hoa Tulip Cầu Vồng', 'Hỗn hợp tulip đầy màu sắc rực rỡ', 935000, 45, 2, 'https://images.unsplash.com/photo-1520763185298-1b434c919102?w=400'),
  ('Bó Hoa Tulip Tím', 'Hoa tulip tím thanh lịch đang nở rộ', 885000, 40, 2, 'https://images.unsplash.com/photo-1557296387-5358ad7997bb?w=400'),
  ('Hoa Tulip Đỏ Đam Mê', 'Hoa tulip đỏ táo bạo tạo ấn tượng mạnh', 861000, 38, 2, 'https://images.unsplash.com/photo-1582794543139-8ac9cb0f7b11?w=400'),
  ('Hoa Tulip Trắng Duyên Dáng', 'Hoa tulip trắng tinh khôi cho vẻ thanh lịch vượt thời gian', 910000, 42, 2, 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=400');

-- Hoa Lily
INSERT INTO products
  (name, description, price, stock, category_id, image_url)
VALUES
  ('Bó Hoa Lily Stargazer', 'Hoa lily stargazer tuyệt đẹp với hương thơm nồng nàn', 1319000, 25, 3, 'https://images.unsplash.com/photo-1524386416438-98b9b2d4b433?w=400'),
  ('Hoa Lily Trắng Tinh Khôi', 'Hoa lily trắng thanh lịch cho những dịp đặc biệt', 1270000, 28, 3, 'https://images.unsplash.com/photo-1587845416217-c2c396f9d21e?w=400'),
  ('Hoa Lily Hổ Cam', 'Hoa lily hổ cam rực rỡ tràn đầy năng lượng', 1175000, 30, 3, 'https://images.unsplash.com/photo-1563241714-b7e9c2e9a137?w=400');

-- Hoa Lan
INSERT INTO products
  (name, description, price, stock, category_id, image_url)
VALUES
  ('Chậu Lan Tím', 'Hoa lan tím kỳ lạ trong chậu trang trí', 1583000, 20, 4, 'https://images.unsplash.com/photo-1565011523534-747a8601f10a?w=400'),
  ('Lan Hồ Điệp Trắng', 'Hoa lan trắng kinh điển cho không gian tinh tế', 1655000, 18, 4, 'https://images.unsplash.com/photo-1594845380981-dd4cc8d08877?w=400'),
  ('Lan Hồng Tầng Bậc', 'Hoa lan hồng tầng bậc trong cắm hoa cao cấp', 1751000, 15, 4, 'https://images.unsplash.com/photo-1585328862928-c797d54ac95d?w=400');

-- Hoa Hướng Dương
INSERT INTO products
  (name, description, price, stock, category_id, image_url)
VALUES
  ('Bó Hướng Dương Hạnh Phúc', 'Hoa hướng dương tươi sáng làm bừng sáng mọi ngày', 791000, 50, 5, 'https://images.unsplash.com/photo-1597848212624-e530bb7d52e2?w=400'),
  ('Hướng Dương Khổng Lồ', 'Hoa hướng dương lớn tạo ấn tượng mạnh mẽ', 1079000, 25, 5, 'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?w=400'),
  ('Hướng Dương Hồng Mix', 'Kết hợp vui vẻ giữa hoa hướng dương và hoa hồng', 1127000, 30, 5, 'https://images.unsplash.com/photo-1563241714-b7e9c2e9a137?w=400');

-- Bó Hoa Hỗn Hợp
INSERT INTO products
  (name, description, price, stock, category_id, image_url)
VALUES
  ('Bó Hoa Vườn Tươi', 'Hỗn hợp hoa tươi từ vườn theo mùa', 1343000, 35, 6, 'https://images.unsplash.com/photo-1487070183336-b863922373d4?w=400'),
  ('Bó Hoa Pastel Mơ Mộng', 'Cắm hoa hỗn hợp với màu pastel nhẹ nhàng', 1415000, 32, 6, 'https://images.unsplash.com/photo-1563514227147-6d2ff665a6a0?w=400'),
  ('Bó Hoa Chúc Mừng Rực Rỡ', 'Lễ hội hoa hỗn hợp đậm và đầy màu sắc', 1511000, 28, 6, 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?w=400'),
  ('Bó Hoa Cao Cấp Sang Trọng', 'Tuyển chọn cao cấp những loại hoa hỗn hợp tốt nhất', 2159000, 20, 6, 'https://images.unsplash.com/photo-1586024297259-c2f0b00768d9?w=400');

-- Hoa Cưới
INSERT INTO products
  (name, description, price, stock, category_id, image_url)
VALUES
  ('Bó Hoa Cô Dâu Cổ Điển', 'Bó hoa cô dâu trắng và kem vượt thời gian', 3023000, 15, 7, 'https://images.unsplash.com/photo-1522673607200-164d1b6ce486?w=400'),
  ('Gói Hoa Cưới Hồng Lãng Mạn', 'Cắm hoa hồng hoàn chỉnh cho lễ cưới', 7199000, 10, 7, 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=400'),
  ('Hoa Trung Tâm Cưới Mộc Mạc', 'Cắm hoa trung tâm mộc mạc quyến rũ', 2063000, 25, 7, 'https://images.unsplash.com/photo-1487070183336-b863922373d4?w=400');

-- Hoa Theo Mùa
INSERT INTO products
  (name, description, price, stock, category_id, image_url)
VALUES
  ('Bộ Sưu Tập Hoa Xuân', 'Hoa xuân tươi trong mùa cao điểm', 1270000, 40, 8, 'https://images.unsplash.com/photo-1520763185298-1b434c919102?w=400'),
  ('Bó Hoa Thu Hoạch', 'Cắm hoa với màu sắc ấm áp của mùa thu', 1319000, 35, 8, 'https://images.unsplash.com/photo-1563241714-b7e9c2e9a137?w=400'),
  ('Hoa Lễ Hội Đặc Biệt', 'Hoa lễ hội cho các dịp kỷ niệm ngày lễ', 1559000, 30, 8, 'https://images.unsplash.com/photo-1487070183336-b863922373d4?w=400');
