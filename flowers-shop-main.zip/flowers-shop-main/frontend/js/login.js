const API_URL = '/api';

// Check if already logged in
if (localStorage.getItem('token')) {
  const user = JSON.parse(
    localStorage.getItem('user') || localStorage.getItem('adminUser') || '{}',
  );
  if (user.role === 'ADMIN') {
    window.location.href = '/admin/';
  } else {
    window.location.href = '/';
  }
}

// Handle login form submission
document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();

  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const errorMsg = document.getElementById('error-message');
  const successMsg = document.getElementById('success-message');
  const submitBtn = e.target.querySelector('button[type="submit"]');

  errorMsg.style.display = 'none';
  successMsg.style.display = 'none';
  submitBtn.disabled = true;
  submitBtn.textContent = 'Đang đăng nhập...';

  try {
    // Use JWT authentication endpoint
    const response = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: username,
        password: password,
      }),
    });

    if (response.ok) {
      const data = await response.json();

      // Store JWT token and user info in localStorage
      localStorage.setItem('token', data.token);

      const userInfo = {
        id: data.id,
        name: data.name,
        email: data.email,
        role: data.role,
      };

      if (data.role === 'ADMIN') {
        localStorage.setItem('adminUser', JSON.stringify(userInfo));
        localStorage.setItem('user', JSON.stringify(userInfo));

        successMsg.textContent =
          'Đăng nhập thành công! Đang chuyển hướng đến trang quản trị...';
        successMsg.style.display = 'block';

        setTimeout(() => {
          window.location.href = '/admin/';
        }, 1000);
      } else {
        localStorage.setItem('user', JSON.stringify(userInfo));

        successMsg.textContent = 'Đăng nhập thành công! Đang chuyển hướng...';
        successMsg.style.display = 'block';

        setTimeout(() => {
          window.location.href = '/';
        }, 1000);
      }
    } else {
      const error = await response.text();
      errorMsg.textContent =
        error || 'Tên đăng nhập hoặc mật khẩu không hợp lệ';
      errorMsg.style.display = 'block';
      submitBtn.disabled = false;
      submitBtn.textContent = 'Đăng Nhập';
    }
  } catch (error) {
    console.error('Login error:', error);
    errorMsg.textContent = 'Lỗi kết nối máy chủ. Vui lòng thử lại.';
    errorMsg.style.display = 'block';
    submitBtn.disabled = false;
    submitBtn.textContent = 'Đăng Nhập';
  }
});
