const API_URL = '/api';

let allProducts = [];
let categories = [];

// Format currency to VND
function formatVND(price) {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
  }).format(price);
}

// Add to cart - global function
window.addToCart = function (productId, productName, price) {
  let cart = JSON.parse(localStorage.getItem('cart') || '[]');

  const existingItem = cart.find((item) => item.id === productId);
  if (existingItem) {
    existingItem.quantity++;
  } else {
    cart.push({
      id: productId,
      name: productName,
      price: price,
      quantity: 1,
    });
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
};

// Load categories from API
async function loadCategories() {
  try {
    const response = await fetch(`${API_URL}/categories`);
    categories = await response.json();
    populateCategoryFilter();
  } catch (error) {
    console.error('Error loading categories:', error);
  }
}

// Populate category filter dropdown
function populateCategoryFilter() {
  const categoryFilter = document.getElementById('category-filter');
  categoryFilter.innerHTML = '<option value="">Tất Cả Danh Mục</option>';

  categories.forEach((category) => {
    const option = document.createElement('option');
    option.value = category.id;
    option.textContent = category.name;
    categoryFilter.appendChild(option);
  });
}

// Load all products or by category
async function loadProducts(categoryId = '', searchTerm = '') {
  try {
    let url = `${API_URL}/products`;

    if (categoryId) {
      url = `${API_URL}/products/category/${categoryId}`;
    }

    const response = await fetch(url);
    allProducts = await response.json();

    // Filter by search term if provided
    if (searchTerm) {
      allProducts = allProducts.filter(
        (product) =>
          product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (product.description &&
            product.description
              .toLowerCase()
              .includes(searchTerm.toLowerCase())),
      );
    }

    displayProducts(allProducts);
  } catch (error) {
    console.error('Error loading products:', error);
    document.getElementById('products-container').innerHTML =
      '<p>Lỗi tải sản phẩm. Vui lòng kiểm tra kết nối.</p>';
  }
}

// Display products
function displayProducts(products) {
  const container = document.getElementById('products-container');

  if (products.length === 0) {
    container.innerHTML = '<p class="no-products">Không tìm thấy sản phẩm.</p>';
    return;
  }

  container.innerHTML = products
    .map(
      (product) => `
        <div class="product-card">
            <div class="product-image">
                <img src="${
                  product.imageUrl ||
                  'https://via.placeholder.com/300x300/667eea/ffffff?text=' +
                    encodeURIComponent(product.name)
                }" 
                     alt="${product.name}" 
                     onerror="this.src='https://via.placeholder.com/300x300/667eea/ffffff?text=Flower'"
                     style="width: 100%; height: 250px; object-fit: cover; border-radius: 10px 10px 0 0;">
            </div>
            <div class="product-info">
                ${
                  product.category
                    ? `<span class="product-category">${product.category.name}</span>`
                    : ''
                }
                <h3>${product.name}</h3>
                <p class="product-description">${
                  product.description || 'Hoa tươi đẹp'
                }</p>
                <div class="product-stock">
                    <span style="color: ${
                      product.stock > 10
                        ? '#10b981'
                        : product.stock > 0
                        ? '#f59e0b'
                        : '#ef4444'
                    }; font-size: 0.9rem; font-weight: 500;">
                        ${
                          product.stock > 0
                            ? `Còn ${product.stock} sản phẩm`
                            : 'Hết hàng'
                        }
                    </span>
                </div>
                <div class="product-price">${formatVND(product.price)}</div>
                <button class="btn btn-primary" onclick="addToCart(${
                  product.id
                }, '${product.name.replace(/'/g, "\\'")}}', ${product.price})" 
                    ${product.stock === 0 ? 'disabled' : ''}>
                    ${product.stock === 0 ? 'Hết Hàng' : 'Thêm Vào Giỏ'}
                </button>
            </div>
        </div>
    `,
    )
    .join('');
}

// Update cart count
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const count = cart.reduce((total, item) => total + item.quantity, 0);
  document.getElementById('cart-count').textContent = count;
}

// Update user menu
function updateUserMenu() {
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const userMenu = document.getElementById('user-menu');
  const loginLink = document.getElementById('login-link');
  const userName = document.getElementById('user-name');

  if (user && user.name) {
    if (userMenu) userMenu.style.display = 'block';
    if (loginLink) loginLink.style.display = 'none';
    if (userName) userName.textContent = user.name;
  } else {
    if (userMenu) userMenu.style.display = 'none';
    if (loginLink) loginLink.style.display = 'block';
  }
}

// Logout function
function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  localStorage.removeItem('adminUser');
  window.location.href = '/';
}

// Initialize page
document.addEventListener('DOMContentLoaded', async () => {
  const urlParams = new URLSearchParams(window.location.search);
  const categoryId = urlParams.get('category');
  const searchTerm = urlParams.get('search');

  // Load categories first
  await loadCategories();

  // Then load products
  if (categoryId) {
    document.getElementById('category-filter').value = categoryId;
    loadProducts(categoryId, searchTerm);
  } else {
    loadProducts('', searchTerm);
  }

  // Category filter change handler
  document.getElementById('category-filter').addEventListener('change', (e) => {
    const selectedCategory = e.target.value;
    const searchInput = document.getElementById('product-search');
    const currentSearch = searchInput ? searchInput.value.trim() : '';
    loadProducts(selectedCategory, currentSearch);

    // Update URL without reload
    const url = new URL(window.location);
    if (selectedCategory) {
      url.searchParams.set('category', selectedCategory);
    } else {
      url.searchParams.delete('category');
    }
    if (currentSearch) {
      url.searchParams.set('search', currentSearch);
    } else {
      url.searchParams.delete('search');
    }
    window.history.pushState({}, '', url);
  });

  // Search input handler
  const searchInput = document.getElementById('product-search');
  if (searchInput) {
    // Set initial value from URL
    if (searchTerm) {
      searchInput.value = searchTerm;
    }

    searchInput.addEventListener('input', (e) => {
      const searchValue = e.target.value.trim();
      const categoryFilter = document.getElementById('category-filter');
      const currentCategory = categoryFilter ? categoryFilter.value : '';
      loadProducts(currentCategory, searchValue);

      // Update URL without reload
      const url = new URL(window.location);
      if (searchValue) {
        url.searchParams.set('search', searchValue);
      } else {
        url.searchParams.delete('search');
      }
      window.history.pushState({}, '', url);
    });
  }

  updateCartCount();
  updateUserMenu();

  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      logout();
    });
  }
});
