-- Categories table
CREATE TABLE
IF NOT EXISTS categories
(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR
(255) NOT NULL UNIQUE,
    description VARCHAR
(1000),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users table
CREATE TABLE
IF NOT EXISTS users
(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR
(255) NOT NULL UNIQUE,
    email VARCHAR
(255) NOT NULL UNIQUE,
    password VARCHAR
(255) NOT NULL,
    full_name VARCHAR
(255),
    phone VARCHAR
(50),
    address VARCHAR
(500),
    role VARCHAR
(50) DEFAULT 'ROLE_USER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE
IF NOT EXISTS products
(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR
(255) NOT NULL,
    description VARCHAR
(1000),
    price DECIMAL
(10, 2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    category_id BIGINT,
    image_url VARCHAR
(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY
(category_id) REFERENCES categories
(id) ON
DELETE
SET NULL
);

-- Orders table
CREATE TABLE
IF NOT EXISTS orders
(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    total_amount DECIMAL
(10, 2) NOT NULL,
    status VARCHAR
(50) DEFAULT 'PENDING',
    shipping_address VARCHAR
(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY
(user_id) REFERENCES users
(id) ON
DELETE CASCADE
);

-- Order items table
CREATE TABLE
IF NOT EXISTS order_items
(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT NOT NULL,
    product_id BIGINT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL
(10, 2) NOT NULL,
    FOREIGN KEY
(order_id) REFERENCES orders
(id) ON
DELETE CASCADE,
    FOREIGN KEY (product_id)
REFERENCES products
(id) ON
DELETE CASCADE
);

-- Indexes for better query performance
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_order_items_product ON order_items(product_id);
