const API_URL = '/api';

// Check if user is logged in
const token = localStorage.getItem('token');
const user = JSON.parse(localStorage.getItem('user') || '{}');

if (!token || !user.id) {
  window.location.href = '/login.html';
}

// Update cart count
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const count = cart.reduce((total, item) => total + item.quantity, 0);
  const badge = document.getElementById('cart-count');
  if (badge) {
    badge.textContent = count;
  }
}

// Update user menu
function updateUserMenu() {
  const userMenu = document.getElementById('user-menu');
  const loginLink = document.getElementById('login-link');
  const userName = document.getElementById('user-name');

  if (user && user.name) {
    if (userMenu) userMenu.style.display = 'block';
    if (loginLink) loginLink.style.display = 'none';
    if (userName) userName.textContent = user.name;
  }
}

// Logout function
function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  localStorage.removeItem('adminUser');
  window.location.href = '/';
}

// Load user profile
async function loadProfile() {
  try {
    const response = await fetch(`${API_URL}/users/${user.id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (response.ok) {
      const userData = await response.json();
      displayProfile(userData);
    } else {
      showMessage('Tải hồ sơ thất bại', 'error');
    }
  } catch (error) {
    console.error('Error loading profile:', error);
    showMessage('Lỗi khi tải hồ sơ', 'error');
  }
}

// Display profile information
function displayProfile(userData) {
  document.getElementById('display-name').textContent = userData.name || '-';
  document.getElementById('display-email').textContent = userData.email || '-';
  document.getElementById('display-phone').textContent = userData.phone || '-';
  document.getElementById('display-address').textContent =
    userData.address || '-';
  document.getElementById('display-role').textContent =
    userData.role === 'ADMIN' ? 'Quản Trị Viên' : 'Khách Hàng';

  // Populate edit form
  document.getElementById('name').value = userData.name || '';
  document.getElementById('phone').value = userData.phone || '';
  document.getElementById('address').value = userData.address || '';
}

// Show message
function showMessage(text, type) {
  const messageEl = document.getElementById('message');
  messageEl.textContent = text;
  messageEl.className = `message ${type}`;
  messageEl.style.display = 'block';

  setTimeout(() => {
    messageEl.style.display = 'none';
  }, 5000);
}

// Toggle edit mode
function toggleEditMode(show) {
  const viewMode = document.getElementById('view-mode');
  const editMode = document.getElementById('edit-mode');

  if (show) {
    viewMode.style.display = 'none';
    editMode.classList.add('active');
  } else {
    viewMode.style.display = 'block';
    editMode.classList.remove('active');
  }
}

// Handle profile form submission
document
  .getElementById('profile-form')
  .addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    const address = document.getElementById('address').value;

    try {
      const response = await fetch(`${API_URL}/users/${user.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...user,
          name: name,
          phone: phone,
          address: address,
        }),
      });

      if (response.ok) {
        const updatedUser = await response.json();

        // Update localStorage
        const storedUser = JSON.parse(localStorage.getItem('user'));
        storedUser.name = updatedUser.name;
        localStorage.setItem('user', JSON.stringify(storedUser));

        // Reload profile
        await loadProfile();
        toggleEditMode(false);
        showMessage('Profile updated successfully!', 'success');
        updateUserMenu();
      } else {
        showMessage('Failed to update profile', 'error');
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      showMessage('Error updating profile', 'error');
    }
  });

// Event listeners
document.getElementById('edit-btn').addEventListener('click', () => {
  toggleEditMode(true);
});

document.getElementById('cancel-btn').addEventListener('click', () => {
  toggleEditMode(false);
});

const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) {
  logoutBtn.addEventListener('click', (e) => {
    e.preventDefault();
    logout();
  });
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadProfile();
  updateCartCount();
  updateUserMenu();
});
