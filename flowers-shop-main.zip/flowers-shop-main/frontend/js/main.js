const API_URL = '/api';

// Toast notification
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${
      type === 'success' ? '✓' : type === 'error' ? '✗' : 'ℹ'
    }</span>
    <span class="toast-message">${message}</span>
  `;
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add('show'), 10);
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// Category icon mapping
const categoryIcons = {
  Roses: '🌹',
  Tulips: '🌷',
  Lilies: '🌺',
  Bouquets: '💐',
  Sunflowers: '🌻',
  Orchids: '🌸',
  Carnations: '🌺',
  Daisies: '🌼',
};

// Format price to VND
function formatVND(price) {
  return price.toLocaleString('vi-VN') + '₫';
}

// Add to cart
window.addToCart = function (productId, productName, price) {
  let cart = JSON.parse(localStorage.getItem('cart') || '[]');

  const existingItem = cart.find((item) => item.id === productId);
  if (existingItem) {
    existingItem.quantity++;
  } else {
    cart.push({
      id: productId,
      name: productName,
      price: price,
      quantity: 1,
    });
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
  showToast('Đã thêm sản phẩm vào giỏ hàng!', 'success');
};

// Load featured products on home page
async function loadFeaturedProducts() {
  try {
    const response = await fetch(`${API_URL}/products`);
    const products = await response.json();

    const container = document.getElementById('featured-products');
    if (container) {
      container.innerHTML = products
        .slice(0, 4)
        .map(
          (product) => `
                <div class="product-card">
                    <div class="product-image">
                        <img src="${
                          product.imageUrl ||
                          'https://via.placeholder.com/300x300/667eea/ffffff?text=' +
                            encodeURIComponent(product.name)
                        }" 
                             alt="${product.name}" 
                             onerror="this.src='https://via.placeholder.com/300x300/667eea/ffffff?text=Flower'"
                             style="width: 100%; height: 250px; object-fit: cover; border-radius: 10px 10px 0 0;">
                    </div>
                    <div class="product-info">
                        <h3>${product.name}</h3>
                        <p>${product.description || 'Hoa đẹp'}</p>
                        <div class="product-price">${formatVND(
                          product.price,
                        )}</div>
                        <button class="btn btn-primary" onclick="event.stopPropagation(); addToCart(${
                          product.id
                        }, '${product.name.replace(/'/g, "\\'")}', ${
            product.price
          })">Thêm Vào Giỏ</button>
                    </div>
                </div>
            `,
        )
        .join('');
    }
  } catch (error) {
    console.error('Error loading products:', error);
  }
}

// Load categories dynamically
async function loadCategories() {
  try {
    const response = await fetch(`${API_URL}/categories`);
    const categories = await response.json();

    const container = document.querySelector('.category-grid');
    if (container) {
      container.innerHTML = categories
        .map(
          (category) => `
            <div
              class="category-card"
              onclick="location.href='/products.html?category=${encodeURIComponent(
                category.id,
              )}'"
            >
              <h3>${categoryIcons[category.name] || '🌸'} ${category.name}</h3>
            </div>
          `,
        )
        .join('');
    }
  } catch (error) {
    console.error('Error loading categories:', error);
  }
}

// Update cart count
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const count = cart.reduce((total, item) => total + item.quantity, 0);
  const badge = document.getElementById('cart-count');
  if (badge) {
    badge.textContent = count;
  }
}

// Update user menu
function updateUserMenu() {
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const userMenu = document.getElementById('user-menu');
  const loginLink = document.getElementById('login-link');
  const userName = document.getElementById('user-name');

  if (user && user.name) {
    if (userMenu) userMenu.style.display = 'block';
    if (loginLink) loginLink.style.display = 'none';
    if (userName) userName.textContent = user.name;
  } else {
    if (userMenu) userMenu.style.display = 'none';
    if (loginLink) loginLink.style.display = 'block';
  }
}

// Logout function
function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  localStorage.removeItem('adminUser');
  window.location.href = '/';
}

// Search products
window.searchProducts = function () {
  const searchInput = document.getElementById('search-input');
  const searchTerm = searchInput.value.trim();

  if (searchTerm) {
    window.location.href = `/products.html?search=${encodeURIComponent(
      searchTerm,
    )}`;
  }
};

// Enable search on Enter key
document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        searchProducts();
      }
    });
  }
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadFeaturedProducts();
  loadCategories();
  updateCartCount();
  updateUserMenu();

  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      logout();
    });
  }
});
